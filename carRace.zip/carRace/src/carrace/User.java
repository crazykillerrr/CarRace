package carrace;

import javafx.scene.input.KeyCode;

/**
 * User class to handle player car movement.
 */
public class User {
    private  FXMLDocumentController controller; 
    private final double step = 5;

 
    public User(FXMLDocumentController controller) {
        this.controller = controller;
    }
    public void movement(KeyCode code) {
        double x = controller.user.getLayoutX(); // Current X position
        double y = controller.user.getLayoutY(); // Current Y position

        switch (code) {
            case RIGHT : 
                controller.user.setLayoutX(x + step);
                break;
            case LEFT : 
                controller.user.setLayoutX(x - step);
                break;
            case DOWN :
                controller.user.setLayoutY(y + step);
                break;
            case UP : 
                controller.user.setLayoutY(y - step);
                break;
        }

        preventOutOfBounds();
    }


    private void preventOutOfBounds() {
        double minX = 100; // Minimum X position
        double maxX = 500; // Maximum X position
        double minY = 0; // Minimum Y position
        double maxY = controller.scene.getHeight() - controller.user.getFitHeight(); // Maximum Y position

        double x = controller.user.getLayoutX();
        double y = controller.user.getLayoutY();

        if (x < minX) {
            controller.user.setLayoutX(minX);
        } else if (x > maxX) {
            controller.user.setLayoutX(maxX);
        }

        if (y < minY) {
            controller.user.setLayoutY(minY);
        } else if (y > maxY) {
            controller.user.setLayoutY(maxY);
        }
    }
}

package carrace;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import java.util.Random;

/**
 * Enemy class for managing enemy cars in the game.
 */
public class Enemy {

    private final AnchorPane scene; // Game scene for adding/removing enemies
    private final ImageView user; // Reference to the player's car
    private final Random random = new Random(); // Random generator for positions
    private final FXMLDocumentController controller; // Reference to the main controller
    private final int minX = 100; // Minimum X coordinate for spawning
    private final int maxX = 500; // Maximum X coordinate for spawning
    private boolean gameOver = false; // Tracks the game-over state

    public Enemy(AnchorPane scene, ImageView user, FXMLDocumentController controller) {
        this.scene = scene;
        this.user = user;
        this.controller = controller;
    }

    public void startEnemySpawning() {
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(5), event -> spawnRandomEnemy()));
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    public void spawnRandomEnemy() {
        if (gameOver) return;

        // Randomly select enemy image
        String[] enemies = {"enemy1.png", "enemy2.png", "enemy3.png", "enemy4.png", "enemy5.png"};
        String enemyImage = enemies[random.nextInt(enemies.length)];

        // Create enemy ImageView
        ImageView enemy = new ImageView();
        enemy.setImage(new javafx.scene.image.Image(getClass().getResource("/img/" + enemyImage).toString()));
        enemy.setFitWidth(user.getFitWidth());
        enemy.setFitHeight(user.getFitHeight());

        // Set random position
        double randomX = getRandomXPosition(enemy);
        enemy.setLayoutX(randomX);
        enemy.setLayoutY(-100);
        scene.getChildren().add(enemy);

        moveEnemyDown(enemy);
    }

    public double getRandomXPosition(ImageView newEnemy) {
        double randomX;
        boolean validPosition;

        do {
            validPosition = true;
            randomX = minX + random.nextDouble() * (maxX - minX);
            newEnemy.setLayoutX(randomX);

            // Check if the position overlaps with existing enemies
            for (Node node : scene.getChildren()) {
                if (node instanceof ImageView && node != newEnemy && node != user) {
                    ImageView existingEnemy = (ImageView) node;
                    if (existingEnemy.getLayoutY() < 0 &&
                        existingEnemy.getBoundsInParent().intersects(newEnemy.getBoundsInParent())) {
                        validPosition = false;
                        break;
                    }
                }
            }
        } while (!validPosition);

        return randomX;
    }

    public void moveEnemyDown(ImageView enemy) {
        TranslateTransition transition = new TranslateTransition();
        transition.setNode(enemy);
        transition.setCycleCount(1);
        transition.setInterpolator(javafx.animation.Interpolator.LINEAR);
        transition.setDuration(Duration.seconds(5));
        transition.setByY(scene.getHeight() + 10);

        // Collision check timeline
        Timeline collisionCheckTimeline = new Timeline(new KeyFrame(Duration.seconds(0.1), event -> {
            if (enemy.getBoundsInParent().intersects(user.getBoundsInParent())) {
                scene.getChildren().remove(enemy); // Remove enemy
                controller.endGame(); // Delegate to controller to handle game over
            }
        }));

        collisionCheckTimeline.setCycleCount(Timeline.INDEFINITE);
        collisionCheckTimeline.play();

        transition.setOnFinished(event -> {
            scene.getChildren().remove(enemy); // Remove enemy after it moves out
            collisionCheckTimeline.stop();

            if (!gameOver) {
                controller.score += 5; // Delegate score increment to controller
                controller.scoreLabel.setText("Score: " + controller.score);
            }
        });

        transition.play();
    }

    public void stopEnemies() {
        gameOver = true; // Stop spawning new enemies
    }

    public void clearEnemies() {
        // Remove all enemies from the scene
        scene.getChildren().removeIf(node -> node instanceof ImageView && node != user);
    }
}

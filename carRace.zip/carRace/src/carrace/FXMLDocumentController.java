// Package declaration
package carrace;

import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;
import javafx.scene.Node;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ddzul
 */

public class FXMLDocumentController implements Initializable {

    @FXML
    public ImageView user;  // The car
    @FXML
    public AnchorPane scene;
    @FXML
    private Label gameOverLabel;  // Label to display "Game Over"
    @FXML
    public Label scoreLabel;  // Label for current score
    @FXML
    private Label finalScoreLabel;  // Label to display final score
    @FXML
    private Button exitButton;  // Exit button
    @FXML
    private Button restartButton;  // Restart button

    private double step = 5;

    private Random random = new Random();
    User userController;
    Enemy enemyController;

    public int score = 0;  // Initialize score
    private Timeline moveForwardTimeline;
    private boolean gameOver = false;
    @FXML
    private ImageView track;
    @FXML
    private Rectangle bgGameOver;
    @FXML
    private ImageView exitBtn2;
    @FXML
    private ImageView restartBtn;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        userController = new User(this);
        enemyController = new Enemy(scene, user, this);

        user.setFocusTraversable(true);
        user.requestFocus();
        scene.setOnKeyPressed(this::onKeyPressed);

        gameOverLabel.setVisible(false);
        finalScoreLabel.setVisible(false);
        exitButton.setVisible(false);
        restartButton.setVisible(false);

        enemyController.startEnemySpawning();
        startMovingForward();
    }

    private void startMovingForward() {
        moveForwardTimeline = new Timeline(new KeyFrame(Duration.seconds(0.1), event -> {
            if (!gameOver) {
                double y = user.getLayoutY();
                user.setLayoutY(y - step); // Bergerak naik secara otomatis
            }
        }));
        moveForwardTimeline.setCycleCount(Timeline.INDEFINITE);
        moveForwardTimeline.play();
    }

    @FXML
    private void onKeyPressed(KeyEvent event) {
        if (gameOver) return;
        userController.movement(event.getCode());
    }

    public void endGame() {
        gameOver = true;
        moveForwardTimeline.stop();

        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("GameOver.fxml"));
            javafx.scene.Scene gameOverScene = new javafx.scene.Scene(loader.load());
            GameOverController controller = loader.getController();
            controller.setFinalScore(score); // Kirim skor akhir ke layar Game Over
            controller.setPrimaryStage((Stage) scene.getScene().getWindow()); // Kirim stage utama
            Stage stage = (Stage) scene.getScene().getWindow();
            stage.setScene(gameOverScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void exitGame() {
        System.exit(0);
    }

    @FXML
    public void restartGame() {
        gameOver = false;
        score = 0;
        exitBtn2.setVisible(false);
        scoreLabel.setText("Score: 0");
        bgGameOver.setVisible(false);
        gameOverLabel.setVisible(false);
        finalScoreLabel.setVisible(false);
        exitButton.setVisible(false);
        restartButton.setVisible(false);

        // Reset posisi mobil
        user.setLayoutX(367);
        user.setLayoutY(481);

        // Hapus musuh yang tersisa
        scene.getChildren().removeIf(node -> node instanceof ImageView && node != user && node != track);

        // Mulai pergerakan maju otomatis dan spawning musuh
        startMovingForward();
        enemyController.startEnemySpawning();
    }
}

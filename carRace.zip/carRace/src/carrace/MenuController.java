/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML.java to edit this template
 */

package carrace;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ddzul
 */

public class MenuController implements Initializable {

    @FXML
    private ImageView playBtn;
    @FXML
    private ImageView exitBtn;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Tambahkan aksi untuk ImageView sebagai tombol
        playBtn.setOnMouseClicked(event -> startGame());
        exitBtn.setOnMouseClicked(event -> exitApplication());
    }

    // Method untuk memulai permainan
    private void startGame() {
        // Logika untuk memuat scene permainan (pindah ke game FXML)
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("FXMLDocument.fxml"));
            javafx.scene.Scene gameScene = new javafx.scene.Scene(loader.load());
            Stage stage = (Stage) playBtn.getScene().getWindow(); // Dapatkan stage dari tombol
            stage.setScene(gameScene); // Set scene baru
            stage.show(); // Tampilkan stage
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method untuk keluar dari aplikasi
    private void exitApplication() {
        System.exit(0); // Keluar dari aplikasi
    }
}

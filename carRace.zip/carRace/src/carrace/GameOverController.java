/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package carrace;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ddzul
 */
public class GameOverController implements Initializable {
  
    @FXML
    private Label finalScoreLabel; // Label untuk menampilkan skor akhir
    private Button restartButton; // Tombol untuk memulai ulang game
    private Button exitButton; // Tombol untuk keluar dari game

    private Stage primaryStage;
    private int finalScore;
    @FXML
    private ImageView exitBtn2;
    @FXML
    private ImageView restartBtn;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Tambahkan aksi untuk ImageView sebagai tombol
        restartBtn.setOnMouseClicked(event -> restartGame());
        exitBtn2.setOnMouseClicked(event -> exitGame());
    }

    // Metode untuk mengatur skor akhir yang ditampilkan
    public void setFinalScore(int score) {
        this.finalScore = score;
        finalScoreLabel.setText("Your Score: " + score);
    }

    // Metode untuk menangkap Stage utama dari layar Game Over
    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }

    // Metode untuk memulai ulang game
    private void restartGame() {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("FXMLDocument.fxml"));
            javafx.scene.Scene gameScene = new javafx.scene.Scene(loader.load());
            primaryStage.setScene(gameScene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Metode untuk keluar dari game
    private void exitGame() {
        System.exit(0);
    }
}


    /**
     * Initializes the controller class.
     */
   
